// check only
public class Check extends Solve {
  protected void works(){
  }
}
