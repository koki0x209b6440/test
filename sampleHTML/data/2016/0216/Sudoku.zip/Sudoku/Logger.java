
public class Logger {
  public void show(String text){
    System.out.println(text);
  }
}
